IMPERIAL HOME SERVICES LLC — WEBSITE FILES

Files:
- index.html: Website structure and page content
- styles.css: Responsive styling and visual design
- script.js: Mobile navigation and appointment request form behavior

HOW TO PREVIEW
1. Extract the ZIP.
2. Keep all three files in the same folder.
3. Open index.html in a modern browser.
4. Internet access is required for Google Fonts and the remote photography used in this draft.

APPOINTMENT REQUEST FORM
The form validates the required fields and opens the visitor's SMS app with a prefilled appointment request addressed to +1 (404) 729-7451. The visitor must press Send. This is a request only; it does not confirm a booking or check live availability.

BEFORE PUBLISHING
- Confirm the business's physical address and service area.
- Confirm business hours.
- Confirm the business's preferred appointment intake method.
- Replace/approve the remote photos and confirm permission to use them.
- If you want requests delivered automatically without the visitor sending an SMS, connect a form backend or booking/CRM service.
- Confirm the Google rating and review excerpts are current and authorized for display.

No physical address, email address, live scheduling availability, or business hours were supplied, so these have not been invented.

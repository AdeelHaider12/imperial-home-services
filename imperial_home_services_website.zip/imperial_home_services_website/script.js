const menuButton = document.querySelector(".menu-toggle");
const nav = document.querySelector(".main-nav");

menuButton.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(isOpen));
  menuButton.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
});

nav.querySelectorAll("a").forEach(link => {
  link.addEventListener("click", () => {
    nav.classList.remove("open");
    menuButton.setAttribute("aria-expanded", "false");
  });
});

document.getElementById("year").textContent = new Date().getFullYear();

// Do not allow selecting a date in the past.
const dateInput = document.getElementById("preferred-date");
const today = new Date();
const localToday = new Date(today.getTime() - today.getTimezoneOffset() * 60000)
  .toISOString().slice(0, 10);
dateInput.min = localToday;

document.getElementById("appointment-form").addEventListener("submit", event => {
  event.preventDefault();
  const form = event.currentTarget;
  if (!form.reportValidity()) return;

  const data = new FormData(form);
  const lines = [
    "Hello Imperial Home Services LLC, I would like to request an appointment.",
    "",
    `Name: ${data.get("name")}`,
    `Phone: ${data.get("phone")}`,
    `Email: ${data.get("email") || "Not provided"}`,
    `Service: ${data.get("service")}`,
    `Preferred date: ${data.get("date")}`,
    `Preferred time: ${data.get("time")}`,
    `Service address: ${data.get("address") || "Not provided"}`,
    `Details: ${data.get("message") || "Not provided"}`,
    "",
    "I understand this is a request and the appointment is not confirmed until your team replies."
  ];

  const smsUrl = `sms:+14047297451?&body=${encodeURIComponent(lines.join("\n"))}`;
  const feedback = document.getElementById("form-feedback");
  feedback.textContent = "Your request is ready. Your messaging app should open so you can send it to the business.";
  window.location.href = smsUrl;
});
